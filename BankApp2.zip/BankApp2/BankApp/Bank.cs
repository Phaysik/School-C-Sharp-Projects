﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    class Bank
    {

        public string AccountName { get; set; }
        public double AccountBalance { get; set; }
        public int AccountNum { get; set; }
        public int AccountPin { get; set; }
    }
}
