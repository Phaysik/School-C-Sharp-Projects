﻿namespace DrawShapes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.picBall1 = new System.Windows.Forms.PictureBox();
            this.picBall6 = new System.Windows.Forms.PictureBox();
            this.picBall5 = new System.Windows.Forms.PictureBox();
            this.picBall4 = new System.Windows.Forms.PictureBox();
            this.picBall3 = new System.Windows.Forms.PictureBox();
            this.picBall2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBall1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(352, 260);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(352, 302);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(75, 23);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // picBall1
            // 
            this.picBall1.Image = global::DrawShapes.Properties.Resources._69032552_red_bowling_ball_isolated_on_transparent_background_vector_illustration;
            this.picBall1.Location = new System.Drawing.Point(12, 7);
            this.picBall1.Name = "picBall1";
            this.picBall1.Size = new System.Drawing.Size(27, 21);
            this.picBall1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBall1.TabIndex = 2;
            this.picBall1.TabStop = false;
            // 
            // picBall6
            // 
            this.picBall6.Image = global::DrawShapes.Properties.Resources._69032552_red_bowling_ball_isolated_on_transparent_background_vector_illustration;
            this.picBall6.Location = new System.Drawing.Point(257, 320);
            this.picBall6.Name = "picBall6";
            this.picBall6.Size = new System.Drawing.Size(27, 21);
            this.picBall6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBall6.TabIndex = 3;
            this.picBall6.TabStop = false;
            // 
            // picBall5
            // 
            this.picBall5.Image = global::DrawShapes.Properties.Resources._69032552_red_bowling_ball_isolated_on_transparent_background_vector_illustration;
            this.picBall5.Location = new System.Drawing.Point(35, 327);
            this.picBall5.Name = "picBall5";
            this.picBall5.Size = new System.Drawing.Size(27, 21);
            this.picBall5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBall5.TabIndex = 4;
            this.picBall5.TabStop = false;
            // 
            // picBall4
            // 
            this.picBall4.Image = global::DrawShapes.Properties.Resources._69032552_red_bowling_ball_isolated_on_transparent_background_vector_illustration;
            this.picBall4.Location = new System.Drawing.Point(10, 160);
            this.picBall4.Name = "picBall4";
            this.picBall4.Size = new System.Drawing.Size(27, 21);
            this.picBall4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBall4.TabIndex = 5;
            this.picBall4.TabStop = false;
            // 
            // picBall3
            // 
            this.picBall3.Image = global::DrawShapes.Properties.Resources._69032552_red_bowling_ball_isolated_on_transparent_background_vector_illustration;
            this.picBall3.Location = new System.Drawing.Point(328, 22);
            this.picBall3.Name = "picBall3";
            this.picBall3.Size = new System.Drawing.Size(27, 21);
            this.picBall3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBall3.TabIndex = 6;
            this.picBall3.TabStop = false;
            // 
            // picBall2
            // 
            this.picBall2.Image = global::DrawShapes.Properties.Resources._69032552_red_bowling_ball_isolated_on_transparent_background_vector_illustration;
            this.picBall2.Location = new System.Drawing.Point(246, 22);
            this.picBall2.Name = "picBall2";
            this.picBall2.Size = new System.Drawing.Size(27, 21);
            this.picBall2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBall2.TabIndex = 7;
            this.picBall2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DrawShapes.Properties.Resources.shapes;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(563, 548);
            this.Controls.Add(this.picBall2);
            this.Controls.Add(this.picBall3);
            this.Controls.Add(this.picBall4);
            this.Controls.Add(this.picBall5);
            this.Controls.Add(this.picBall6);
            this.Controls.Add(this.picBall1);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picBall1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBall2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.PictureBox picBall1;
        private System.Windows.Forms.PictureBox picBall6;
        private System.Windows.Forms.PictureBox picBall5;
        private System.Windows.Forms.PictureBox picBall2;
        private System.Windows.Forms.PictureBox picBall3;
        private System.Windows.Forms.PictureBox picBall4;
    }
}

